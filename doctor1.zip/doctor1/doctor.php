<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="doctor.css">
    <title>Doctor Page</title>
</head>
<body>
    <a href="index.html">
        <button>Go Back to Index</button>
    </a>
    <h2>Doctor Page</h2>

    <h3>Appointments:</h3>

    <ul id="appointmentsList">
        <?php
        include 'database.php';
        $sql = "SELECT a.*, p.Name, p.Telephone FROM appointments a INNER JOIN patients p ON a.PatientID = p.ID";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<li>{$row['Name']} - Patient: {$row['Name']} - Date: {$row['DateAndTime']}</li>";
            }
        }
        ?>
    </ul>

    

    <h3>Add Availability:</h3>
    <label for="availabilityDate">Date:</label>
    <input type="date" id="availabilityDate">

    <label for="availabilityTime">Time:</label>
    <input type="time" id="availabilityTime">

    <button onclick="addAvailability()">Add Availability</button>

    <h3>Add Absence:</h3>
    <label for="absenceDate">Date:</label>
    <input type="date" id="absenceDate">

    <label for="absenceTime">Time:</label>
    <input type="time" id="absenceTime">

    <button onclick="addAbsence()">Add Absence</button>

    <button onclick="goBack()">Go Back</button>

    <script>
        function addAvailability() {
            var date = document.getElementById("availabilityDate").value;
            var time = document.getElementById("availabilityTime").value;
        }
        function addAbsence() {
            var date = document.getElementById("absenceDate").value;
            var time = document.getElementById("absenceTime").value;
        }
        function goBack() {
        window.location.href = "index.html";
        }
    </script>
   
</body>
</html>
