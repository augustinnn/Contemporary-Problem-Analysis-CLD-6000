<?php
$servername = "localhost:8889";
$username = "root";
$password = "root";
$dbname = "Hospital";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function getDoctors() {
    global $conn;
    $sql = "SELECT * FROM Doctors";
    $result = $conn->query($sql);
    $doctors = array();
    echo "after loop";
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $doctors[] = $row;
        }
    }
    return $doctors;
}

function getAvailableDates($doctorId) {
    global $conn;
    $sql = "SELECT * FROM Available WHERE DoctorID = $doctorId";
    $result = $conn->query($sql);
    $dates = array();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $dates[] = $row;
        }
    }
    return $dates;
}

function bookAppointment($doctorId, $customerId, $dateTime) {
    global $conn;
    $sql = "INSERT INTO Appointments (DoctorID, PatientID, DateAndTime) VALUES ($doctorId, $customerId, '$dateTime')";
    $conn->query($sql);
    $sql = "DELETE FROM Available WHERE DoctorID = $doctorId AND DateAndTime = '$dateTime'";
    $conn->query($sql);
}

function addCustomer($name, $telephone) {
    global $conn;
    $sql = "INSERT INTO Patients (Name, Telephone) VALUES ('$name', '$telephone')";
    $conn->query($sql);
    return $conn->insert_id;
}
?>
