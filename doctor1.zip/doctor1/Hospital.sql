-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Gazdă: localhost:8889
-- Timp de generare: ian. 19, 2024 la 01:00 PM
-- Versiune server: 5.7.39
-- Versiune PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Bază de date: `Hospital`
--

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `Absence`
--

CREATE TABLE `Absence` (
  `ID` int(11) NOT NULL,
  `DoctorID` int(11) DEFAULT NULL,
  `AbsenceDate` date DEFAULT NULL,
  `AbsenceTime` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Eliminarea datelor din tabel `Absence`
--

INSERT INTO `Absence` (`ID`, `DoctorID`, `AbsenceDate`, `AbsenceTime`) VALUES
(1, 1, '2024-01-23', '08:00:00'),
(2, 2, '2024-01-23', '08:00:00');

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `Appointments`
--

CREATE TABLE `Appointments` (
  `ID` int(11) NOT NULL,
  `DoctorID` int(11) DEFAULT NULL,
  `PatientID` int(11) DEFAULT NULL,
  `AppointmentDate` date DEFAULT NULL,
  `AppointmentTime` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Eliminarea datelor din tabel `Appointments`
--

INSERT INTO `Appointments` (`ID`, `DoctorID`, `PatientID`, `AppointmentDate`, `AppointmentTime`) VALUES
(1, 1, 1, '2024-01-18', '10:00:00'),
(2, 2, 2, '2024-01-18', '12:30:00'),
(3, 1, 3, '2024-01-18', '12:00:00'),
(4, 2, 4, '2024-01-18', '15:30:00'),
(5, 1, 5, '2024-01-19', '09:00:00'),
(6, 2, 6, '2024-01-19', '11:30:00'),
(7, 1, 7, '2024-01-19', '10:30:00'),
(8, 2, 8, '2024-01-19', '14:30:00'),
(9, 1, 9, '2024-01-20', '11:00:00');

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `Available`
--

CREATE TABLE `Available` (
  `ID` int(11) NOT NULL,
  `DoctorID` int(11) DEFAULT NULL,
  `AvailableDate` date DEFAULT NULL,
  `AvailableTime` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Eliminarea datelor din tabel `Available`
--

INSERT INTO `Available` (`ID`, `DoctorID`, `AvailableDate`, `AvailableTime`) VALUES
(1, 1, '2024-01-18', '14:00:00'),
(2, 1, '2024-01-19', '12:00:00'),
(3, 1, '2024-01-20', '12:00:00'),
(4, 1, '2024-01-21', '08:00:00'),
(5, 1, '2024-01-22', '08:00:00'),
(6, 2, '2024-01-18', '08:00:00'),
(7, 2, '2024-01-19', '15:00:00'),
(8, 2, '2024-01-20', '13:00:00'),
(9, 2, '2024-01-21', '08:00:00');

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `Doctors`
--

CREATE TABLE `Doctors` (
  `ID` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Speciality` varchar(50) NOT NULL,
  `AppointmentDuration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Eliminarea datelor din tabel `Doctors`
--

INSERT INTO `Doctors` (`ID`, `Name`, `Speciality`, `AppointmentDuration`) VALUES
(1, 'Dr. Augustin', 'Cardiology', 30),
(2, 'Dr. Brinza', 'Orthopedics', 45);

-- --------------------------------------------------------

--
-- Structură tabel pentru tabel `Patients`
--

CREATE TABLE `Patients` (
  `ID` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Telephone` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Eliminarea datelor din tabel `Patients`
--

INSERT INTO `Patients` (`ID`, `Name`, `Telephone`) VALUES
(1, 'Jane Austen', '0722334455'),
(2, 'Verna Aardema', '0722334455'),
(3, 'Jonathan Aaron', '0722334455'),
(4, 'Diane Ackerman', '0722334455'),
(5, 'Martha Ackmann', '0722334455'),
(6, 'Grigol Abashidze', '0722334455'),
(7, 'Forrest J. Ackerman', '0722334455'),
(8, 'Ines Abassi', '0722334455'),
(9, 'Milton Acorn', '0722334455');

--
-- Indexuri pentru tabele eliminate
--

--
-- Indexuri pentru tabele `Absence`
--
ALTER TABLE `Absence`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `FK_Doctor_Absence` (`DoctorID`);

--
-- Indexuri pentru tabele `Appointments`
--
ALTER TABLE `Appointments`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `FK_Doctor_Appointment` (`DoctorID`),
  ADD KEY `FK_Patient_Appointment` (`PatientID`);

--
-- Indexuri pentru tabele `Available`
--
ALTER TABLE `Available`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `FK_Doctor_Available` (`DoctorID`);

--
-- Indexuri pentru tabele `Doctors`
--
ALTER TABLE `Doctors`
  ADD PRIMARY KEY (`ID`);

--
-- Indexuri pentru tabele `Patients`
--
ALTER TABLE `Patients`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT pentru tabele eliminate
--

--
-- AUTO_INCREMENT pentru tabele `Absence`
--
ALTER TABLE `Absence`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pentru tabele `Appointments`
--
ALTER TABLE `Appointments`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT pentru tabele `Available`
--
ALTER TABLE `Available`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT pentru tabele `Doctors`
--
ALTER TABLE `Doctors`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pentru tabele `Patients`
--
ALTER TABLE `Patients`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constrângeri pentru tabele eliminate
--

--
-- Constrângeri pentru tabele `Absence`
--
ALTER TABLE `Absence`
  ADD CONSTRAINT `FK_Doctor_Absence` FOREIGN KEY (`DoctorID`) REFERENCES `Doctors` (`ID`);

--
-- Constrângeri pentru tabele `Appointments`
--
ALTER TABLE `Appointments`
  ADD CONSTRAINT `FK_Doctor_Appointment` FOREIGN KEY (`DoctorID`) REFERENCES `Doctors` (`ID`),
  ADD CONSTRAINT `FK_Patient_Appointment` FOREIGN KEY (`PatientID`) REFERENCES `Patients` (`ID`);

--
-- Constrângeri pentru tabele `Available`
--
ALTER TABLE `Available`
  ADD CONSTRAINT `FK_Doctor_Available` FOREIGN KEY (`DoctorID`) REFERENCES `Doctors` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
