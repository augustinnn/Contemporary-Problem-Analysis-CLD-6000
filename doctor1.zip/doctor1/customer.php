<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="doctor.css">
    <title>Customer Page</title>
</head>
<body>
    <a href="index.html">
        <button>Go Back to Index</button>
    </a>
    <h2>Make an appointment</h2>

    <label for="doctorSelect">Select a Doctor:</label>
    
    <select id="doctorSelect">
        <?php
        include 'database.php';
        $doctors = getDoctors();
        foreach ($doctors as $doctor) {
            echo "<option value='{$doctor['ID']}'>{$doctor['Name']} ({$doctor['Speciality']} - {$doctor['Duration']})</option>";
        }
        ?>
    </select>

    <label for="dateSelect">Select an Available Date:</label>
    <select id="dateSelect">
       
    </select>

    <label for="nameInput">Name:</label>
    <input type="text" id="nameInput" placeholder="Enter your name">

    <label for="telephoneInput">Telephone:</label>
    <input type="tel" id="telephoneInput" placeholder="Enter your telephone number">

    <button onclick="submitAppointment()">Submit</button>

    <button onclick="goBack()">Go Back</button>

    <script>
        function submitAppointment() {
            var doctorId = document.getElementById("doctorSelect").value;
            var date = document.getElementById("dateSelect").value;
            var name = document.getElementById("nameInput").value;
            var telephone = document.getElementById("telephoneInput").value;
        }
        document.getElementById("doctorSelect").addEventListener("change", function () {
            var doctorId = this.value;
            var dateSelect = document.getElementById("dateSelect");
        });
        function goBack() {
        window.location.href = "index.html";
    }
    </script>
    <a href="index.html">
        <button>Go Back to Index</button>
    </a>
</body>
</html>