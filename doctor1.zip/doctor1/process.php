<?php
include 'database.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action'])) {
        if ($_POST['action'] == 'bookAppointment') {
            $doctorId = $_POST['DoctorId'];
            $customerId = $_POST['CustomerId'];
            $dateTime = $_POST['DateAndTime'];
            bookAppointment($doctorId, $customerId, $dateTime);
        } elseif ($_POST['action'] == 'addCustomer') {
            $name = $_POST['Name'];
            $telephone = $_POST['Telephone'];
            $customerId = addCustomer($name, $telephone);
            echo $customerId;
        }
    }
}
?>
